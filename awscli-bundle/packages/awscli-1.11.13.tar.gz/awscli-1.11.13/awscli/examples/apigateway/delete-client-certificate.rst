**To delete a client certificate in the specified region**

Command::

  aws apigateway delete-client-certificate --client-certificate-id a1b2c3 --region us-west-2

